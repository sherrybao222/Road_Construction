/*
This contains the instructions for the task extended from the Phaser scene
Class. It use setVisible function to display text.
Not completed flow of instructions
*/

export default class InstructionScene extends Phaser.Scene {
  constructor() {
    super('InstructionScene');
  }

  init(data) {
    this.part = data.part;
    this.textColor = '#1C2833';
    this.nextObj = this.input.keyboard.addKey('enter');  // Get key object

    this.start = getTime();
  };

  preload() {
  };

  create() {
    // add fullscreen button
    fullscreen(this);
    this.timedEvent = this.time.addEvent({ delay: this.registry.values.remainTime, callback: this.end, callbackScope: this });

    // add screen
    this.gameInstruction()


    /*
    // add title
    if (this.part == 1){
      this.basicInstruction();
    } else if (this.part == 2){
      this.undoInstruction();
    } else {
      this.transition();
    }
    */

    //change scenes on key press command
    this.input.keyboard.on('keydown_ENTER', () => this.scene.start('GameScene'));
    /*
    //change scenes on key press command
    if (this.part == 3){
      this.input.keyboard.on('keydown_ENTER', ()=>this.scene.start('GameScene'));
    } else if (this.part == 1){
      this.input.keyboard.on('keydown_ENTER', ()=>this.scene.start('TrainScene', {trialInd:0, cond:2}));
    } else {
      this.input.keyboard.on('keydown_ENTER', ()=>this.scene.start('TrainScene', {trialInd:0, cond:3}));
    }
    */
  };

  update() {
    // timing
    var time = new Date();
    var elapsed = time.getTime() - this.start;
    this.registry.values.remainTime = this.registry.values.remainTime - elapsed;

    if (this.nextObj.isDown) {
      this.scene.start('GameScene');

      /*
      if (this.part == 3){
        this.scene.start('GameScene');
      } else if (this.part == 1){
        this.scene.start('TrainScene', {trialInd:0, cond:2});
      } else {
        this.scene.start('TrainScene', {trialInd:0, cond:3});
      }
      */
    }
  };

  end() {
    this.scene.start("EndScene", { type: 'time' });
  }

  gameInstruction() {
    /*       var title      = 'Instruction Part 1';
          const screenCenterX = this.cameras.main.worldView.x + this.cameras.main.width / 2;
          this.add.text(screenCenterX, 50, title, { fontFamily: 'Comic Sans MS', fontSize: '37px', fontStyle: 'bold', color: this.textColor, aligh: 'center'}).setOrigin(0.5);
     */
    //var text = 'Now you will read the instruction for Road Construction.\nIn Road Construction, you will see a map and a green line as your budget.\nYour goal is to connect as many cities as possible with the given budget.\nThe score bar on the right will show cents you have earned in respect to the number of cities connected.\nPress RETURN to try two examples.'
    var text = 'Press RETURN to play the game.'
    this.add.text(50, 250, text, { fontFamily: 'Comic Sans MS', fontSize: '30px', color: this.textColor, aligh: 'center' });


    // what is coming next
    this.trialCounter = this.registry.values.trialCounter;
    this.nextBlockInd = Math.floor(this.trialCounter / this.registry.values.gameTrialNrBlk);
    this.nextOneAll = this.registry.values.cond[this.nextBlockInd];

    if (this.nextOneAll === 2) {
      var condition = '"Road construction without undo"';

    } else {
      var condition = '"Road construction with undo"';
    }


    var nextSign = `The next group of trials are ${condition} trials.`
    this.add.text(50, 200, nextSign, { fontFamily: 'Comic Sans MS', fontSize: '30px', color: this.textColor, aligh: 'center' });
    // this.add.text(this.screenCenterX, this.sys.game.config.height - 500, nextSign, { fontFamily: 'Comic Sans MS', fontSize: '37px', color: this.textColor, aligh: 'center' }).setOrigin(0.5);




  }

  basicInstruction() {
    /*       var title      = 'Instruction Part 1';
          const screenCenterX = this.cameras.main.worldView.x + this.cameras.main.width / 2;
          this.add.text(screenCenterX, 50, title, { fontFamily: 'Comic Sans MS', fontSize: '37px', fontStyle: 'bold', color: this.textColor, aligh: 'center'}).setOrigin(0.5);
     */
    //var text = 'Now you will read the instruction for Road Construction.\nIn Road Construction, you will see a map and a green line as your budget.\nYour goal is to connect as many cities as possible with the given budget.\nThe score bar on the right will show cents you have earned in respect to the number of cities connected.\nPress RETURN to try two examples.'
    var text = 'Press RETURN to try two examples of basic Road Construction without undo.'
    this.add.text(50, 200, text, { fontFamily: 'Comic Sans MS', fontSize: '30px', color: this.textColor, aligh: 'center' });
  }

  undoInstruction() {
    /*       var title      = 'Instruction Part 2';
          const screenCenterX = this.cameras.main.worldView.x + this.cameras.main.width / 2;
          this.add.text(screenCenterX, 50, title, { fontFamily: 'Comic Sans MS', fontSize: '37px', fontStyle: 'bold', color: this.textColor, aligh: 'center'}).setOrigin(0.5);
     */
    //var text = 'Now you will read the instruction for Road Construction with Undo.\nIn Road Construction with Undo, you will see a map and a green line as your budget.\nYour goal is to connect as many cities as possible with the given budget.\nIn addition, you can press Z to undo your connections.\nThe score bar on the right will show cents you have earned in respect to the number of cities connected.\nand a record of your highest score achieved.\nPress RETURN to try two examples.'
    var text = 'Press RETURN to try two examples of Road Construction with undo.'
    this.add.text(50, 200, text, { fontFamily: 'Comic Sans MS', fontSize: '30px', color: this.textColor, aligh: 'center' });
  }

  transition() {
    //var text = 'Now you have finished the training.\nYou will start the formal game, and every connected cities will be counted towards your performance for that map.\nIn the end, we will randomly choose 2 maps from each condition to calculate your payment.\nPress RETURN to start.'
    var text = 'Now you have finished the training.\nYou will start the formal game, \nand every connected cities will be counted towards your performance for that map.\nPress RETURN to start.'
    this.add.text(50, 200, text, { fontFamily: 'Comic Sans MS', fontSize: '30px', color: this.textColor, aligh: 'center' });
  }
}
