export default class EndScene extends Phaser.Scene {

	constructor() {
		super("EndScene");
	}
	init(data) {
		window.psychoJS.experiment.save(window.psychoJS.experiment)

		this.type = data.type;

		this.textColor = '#1C2833';
		this.warnColor = '#943126';

		this.nextObj = this.input.keyboard.addKey('enter');  // Get key object
		this.screenCenterX = this.cameras.main.worldView.x + this.cameras.main.width / 2;

	}

	create() {
		// add fullscreen button
		fullscreen(this);

		if (this.type === 'fail') {
			var text = 'Unfortunately you have failed the attention check.\nYou cannot continue this game.\nYou can now close this webpage.'
			this.add.text(this.screenCenterX, 400, text, { fontFamily: 'Comic Sans MS', fontSize: '30px', fontStyle: '', color: this.textColor, aligh: 'center' }).setOrigin(0.5);
		} else if (this.type === 'time') {
			var allData = this.createExpData();
			saveTrialData(allData);

			var text = 'You have reached the maximum time for this task.\nThank you for your participation.\n'
			this.add.text(this.screenCenterX, 400, text, { fontFamily: 'Comic Sans MS', fontSize: '30px', fontStyle: '', color: this.textColor, aligh: 'center' }).setOrigin(0.5);
		}
		else {
			var text = 'The task is finished.\nThank you for your participation.\nYou will be paid within 3~5 business days through Prolific.'
			this.add.text(this.screenCenterX, 400, text, { fontFamily: 'Comic Sans MS', fontSize: '30px', fontStyle: '', color: this.textColor, aligh: 'center' }).setOrigin(0.5);
		}

	}

	update() {
		if (!window.navigator.onLine) {
			window.confirm("You turned offline!\nPlease check your internet connection and resume by clicking the OK button.\nIMPORTANT: If you force to close the window while you are disconnected from the internet, your results will not be saved.")
		}
		else {
		}
	}

	createExpData() {
		var expData = {
			timeUp: 1
		};
		return expData;
	}


}
